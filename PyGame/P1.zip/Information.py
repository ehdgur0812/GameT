x_line = 50
y_line = 30

def GetXYSize() :
    return x_line, y_line

