import pygame
import time
import Tile
import TileRotation
import TileCheck
import Information
import Tetris
import GoHero
 
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
x_speed = 20
y_speed = 20

stage_str = "stage" 
game_stage = 1

x_line, y_line = Information.GetXYSize()
        
pygame.init()
screen = pygame.display.set_mode([1100, 600])
pygame.display.set_caption('CMSC 150 is cool')
clock = pygame.time.Clock()

pygame.mixer.music.load("sound\Test.mp3")
pygame.mixer.music.play(-1,0.0)

background_image = pygame.image.load("DarkBG.png").convert()
block_image = ["block\general.png", "block\genadd.png", "block\general.png",
                "block\general.png", "block\genbet.png", "block\general.png",
               "block\general.png", "block\gengoal.png", "block\genbad.png"]
hero_image = pygame.image.load("hero\Jenny_move1.png").convert()
hero_image.set_colorkey((0,0,0))
hero_position = [0,540]

block_list = list()
for index in range(9) :
    block_list.append(pygame.image.load(block_image[index]).convert())
    block_list[index].set_colorkey((0,0,0))

tiles = list()
for y_index in range(y_line) :
    tiles.append(list())
    for x_index in range(x_line) :
        tiles[y_index].append(Tile.TileClass())
        tiles[y_index][x_index].initTile(y_index, x_index, pygame)

def load_File(path) :
    file = open(path, "r")
    line = file.readlines()
    for y_index in range(y_line) :
        x_count = 0
        for x_index in range(x_line*2) :
            if x_index % 2 == 0 :
                if line[y_index][x_index] == '1' :
                    tiles[y_index][x_count].setBlock(1)
                if line[y_index][x_index] == '5' :
                    tiles[y_index][x_count].setBlock(5)
                if line[y_index][x_index] == '8' :
                    tiles[y_index][x_count].setBlock(8)
                if line[y_index][x_index] == '9' :
                    tiles[y_index][x_count].setBlock(9)
                x_count += 1
    file.close()

def play_Game() :
    global stage_str, game_stage
    now_time = time.time()
    down_time = time.time() + 0.5
    frame_time = now_time + 1.0
    frame_count = 0
    
    game_state = False
    game_number = 0

    Tetris.init_Tetris(pygame, tiles, y_line, x_line)
    stage_str += ("\\stage" + str(game_stage) + ".txt")
    load_File(stage_str)

    while not game_state:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_state = True
                break
            else :
                pygame.event.post(event)

        frame_count += 1
        now_time = time.time()
        if now_time >= frame_time :
            print(frame_count)
            frame_count = 0
            frame_time = now_time + 1.0
        
        if game_number == 0 :
            down_time, game_number = Tetris.play_Tetris(pygame, tiles,
                    y_line, x_line, now_time, down_time)
        elif game_number == 1 :
            game_number = GoHero.play_Hero(pygame, hero_position, tiles, y_line, x_line, now_time)
        elif game_number == 9 :
            Tetris.init_Tetris(pygame, tiles, y_line, x_line)
            stage_str = "stage"
            game_stage+=1
            if game_stage == 4 :
                game_stage = 1
            stage_str += ("\\stage" + str(game_stage) + ".txt")
            load_File(stage_str)
            game_number = 0
            
        screen.blit(background_image, [0,0])
        for y_index in range(y_line) :
            for x_index in range(x_line) :
                if tiles[y_index][x_index].block != 0 :
                    screen.blit(block_list[tiles[y_index][x_index].block-1],
                                [tiles[y_index][x_index].x_position,
                                 tiles[y_index][x_index].y_position])
        #screen.blit(hero_image, hero_position)
        GoHero.draw_Hero(screen, hero_image, hero_position)
     
        pygame.display.flip()
        clock.tick(60)

play_Game()
 
pygame.quit()
